-- Tests for TU encoding

checkengines = {"xetex", "luatex"}
checksearch  = true
testfiledir  = "testfiles-TU"
